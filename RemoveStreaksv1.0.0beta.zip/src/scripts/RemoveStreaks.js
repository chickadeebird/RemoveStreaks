
#feature-id RemoveStreaks : ChickadeeScripts > RemoveStreaks
#feature-icon  RemoveStreaks.svg
#feature-info This script allows selection of a streak artifact and its removal.



#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define VERSION "v1.0.0 beta"
#define SCRIPTNAME "Remove Streaks"

#define MODE_REGION_SELECT  0
#define MODE_ANGLE_SELECT   1
#define MODE_FLATTEN_RESIDUAL   2

#define MAX_LAYERS  16


// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    CMD_EXEC = "cmd.exe";
    SCRIPT_EXT = ".bat";
} else {
    console.criticalln("Unsupported platform: " + CoreApplication.platform);
}

// Define platform-agnostic folder paths
// let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "/" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "RSConfig";
let RSConfigFile = scriptTempDir + pathSeparator + "RS_config.csv";
// Console.warningln('Config file location: ' + RSConfigFile);
let diff = true;
while (diff) {
    let newString = RSConfigFile.replace('/', '\\');

    if (newString === RSConfigFile) {
        diff = false;
    }

    RSConfigFile = newString;
}
/*
// RSConfigFile = RSConfigFile.replace(/\//g, '\\');
Console.warningln('RSConfigFile: ' + RSConfigFile);
Console.warningln('File.systemTempDirectory: ' + File.systemTempDirectory);
Console.warningln('scriptTempDir: ' + scriptTempDir);
*/
// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
    File.createDirectory(scriptTempDir);
}



let RSParameters = {
    targetWindow: null,
    maskWindow: null,
    previewZoomLevel: "Fit to Preview",
    shapes: [],
    shapeTypes: [], // Store types of shapes
    autoSTF: true,
    currentMode: MODE_REGION_SELECT,
    RSPythonToolsParentFolderPath: "",
    angle: 0,
    selectedAlgorithm: 0,
    save: function() {
        Parameters.set("shapes", JSON.stringify(this.shapes));
        Parameters.set("shapeTypes", JSON.stringify(this.shapeTypes));
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        Parameters.set("RSPythonToolsParentFolderPath", this.RSPythonToolsParentFolderPath);
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
        this.savePathToFile();
    },
    load: function() {
        if (Parameters.has("shapes")) {
            this.shapes = JSON.parse(Parameters.getString("shapes"));
        }
        if (Parameters.has("shapeTypes")) {
            this.shapeTypes = JSON.parse(Parameters.getString("shapeTypes"));
        }
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("RSPythonToolsParentFolderPath"))
            this.RSPythonToolsParentFolderPath = Parameters.getString("RSPythonToolsParentFolderPath");
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
        this.loadPathFromFile();
    },
    savePathToFile: function () {
        try {
            let file = new File;
            // console.writeln("Writing config file: " + RSConfigFile);
            file.createForWriting(RSConfigFile);
            file.outTextLn(this.RSPythonToolsParentFolderPath);
            file.close();
        } catch (error) {
            console.warningln("Failed to save RSConfigFile parent folder path: " + error.message);
        }
    },
    loadPathFromFile: function () {
        try {
            if (File.exists(RSConfigFile)) {
                let file = new File;
                Console.writeln("Reading config file: " + RSConfigFile);
                file.openForReading(RSConfigFile);
                let lines = File.readLines(RSConfigFile);
                /*
                Console.writeln("Config file lines: " + lines);
                Console.writeln("Config file lines.length: " + lines.length);
                Console.writeln("Config file lines[0]: " + lines[0]);
                */
                // Console.writeln("Config file lines[0].trim: " + lines[0].trim);
                if (lines.length > 0) {
                    this.RSPythonToolsParentFolderPath = lines[0].trim();
                    Console.writeln("RSPythonToolsParentFolderPath: " + this.RSPythonToolsParentFolderPath);
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load RSConfigFile parent folder path: " + error.message);
        }
    }
};

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.isDrawing = false; // Flag for detecting drawing
    this.isTransforming = false; // Flag for detecting transforming (rotate + resize)
    this.currentShape = [];
    this.shapes = [];
    this.shapeTypes = []; // Track types of shapes
    this.activeShapeIndex = 0; // Initialize activeShapeIndex
    this.scrollPosition = new Point(0, 0); // Ensure scrollPosition is always defined
    this.previousZoomLevel = 1;
    this.shapeType = "Freehand"; // Default shape type
    this.transformCenter = null; // Center point for transformations
    this.initialDistance = null; // Initial distance for resizing
    this.initialAngle = null; // Initial angle for rotating
    this.gradientStartPoint = null; // To store the start point of the gradient
    this.gradientEndPoint = null;   // To store the end point of the gradient


    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.zoomFactor = 1;
    this.minZoomFactor = 0.1; // Set the minimum zoom factor for zooming out
    this.maxZoomFactor = 10;  // Set the maximum zoom factor for zooming in

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

this.initScrollBars = function(scrollPoint = null) {
    var image = this.getImage();
    if (image == null || image.width <= 0 || image.height <= 0) {
        this.setHorizontalScrollRange(0, 0);
        this.setVerticalScrollRange(0, 0);
        this.scrollPosition = new Point(0, 0);
    } else {
        let zoomFactor = this.zoomFactor;
        this.setHorizontalScrollRange(0, Math.max(0, (image.width * zoomFactor)));
        this.setVerticalScrollRange(0, Math.max(0, (image.height * zoomFactor)));
        if (scrollPoint) {
            this.scrollPosition = scrollPoint;
        } else {
            this.scrollPosition = new Point(
                Math.min(this.scrollPosition.x, (image.width * zoomFactor)),
                Math.min(this.scrollPosition.y, (image.height * zoomFactor))
            );
        }
    }
    if (this.viewport) {
        this.viewport.update();
    }
};



    this.calculateTransformCenter = function(shape) {
        let sumX = 0;
        let sumY = 0;
        shape.forEach(point => {
            sumX += point[0];
            sumY += point[1];
        });
        return [sumX / shape.length, sumY / shape.length];
    };

    this.calculateDistance = function(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    };

    this.calculateAngle = function(x1, y1, x2, y2) {
        return Math.atan2(y2 - y1, x2 - x1);
    };

    this.transformShape = function(shape, angle, scaleX, scaleY, centerX, centerY) {
        return shape.map(point => {
            let translatedX = point[0] - centerX;
            let translatedY = point[1] - centerY;
            let rotatedX = translatedX * Math.cos(angle) - translatedY * Math.sin(angle);
            let rotatedY = translatedX * Math.sin(angle) + translatedY * Math.cos(angle);
            let resizedX = rotatedX * scaleX;
            let resizedY = rotatedY * scaleY;
            return [resizedX + centerX, resizedY + centerY];
        });
    };

this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;


    // Handle gradient mask point selection with the right mouse button (button === 2)
    if (button === 2) {
        if (!parent.gradientStartPoint) {
            parent.gradientStartPoint = [adjustedX, adjustedY];
            console.writeln("Gradient start point set at: (" + adjustedX + ", " + adjustedY + ")");
parent.viewport.update();
        } else if (!parent.gradientEndPoint) {
            parent.gradientEndPoint = [adjustedX, adjustedY];
            console.writeln("Gradient end point set at: (" + adjustedX + ", " + adjustedY + ")");
parent.viewport.update();
        }
        return;  // Exit after setting the points
    }

    // Existing logic for drawing, moving, or transforming shapes
    if (modifiers === 1) { // Shift key detection for drawing
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isDrawing = true;
        parent.dragging = false; // Prevent scrolling while drawing

        // Handle different shape types
        if (parent.shapeType === "Ellipse" || parent.shapeType === "Rectangle") {
            parent.currentShape = [[parent.startX, parent.startY], [parent.startX, parent.startY]];
        } else if (parent.shapeType === "SprayCan") {
            parent.currentShape = []; // Initialize currentShape for spray can
        } else if (parent.shapeType === "Brush") {
            parent.currentShape = []; // Initialize currentShape for brush strokes
        }
    } else if (modifiers === 2) { // Ctrl key detection for moving
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isMoving = true;
        parent.dragging = false; // Prevent scrolling while moving

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
    } else if (modifiers === 4) { // Alt key detection for transforming
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isTransforming = true;
        parent.transformCenter = parent.calculateTransformCenter(parent.shapes[parent.activeShapeIndex]);
        parent.initialAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], parent.startX, parent.startY);
        parent.initialDistance = parent.calculateDistance(parent.startX, parent.startY, parent.transformCenter[0], parent.transformCenter[1]);

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
    } else {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        parent.dragging = true;
    }
};



this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;
    if (parent.isDrawing) {
        let endX = adjustedX;
        let endY = adjustedY;

        if (parent.shapeType === "Freehand") {

            if (RSParameters.currentMode === MODE_REGION_SELECT) {
                parent.currentShape.push([endX, endY]);
            }
            else {
                if (parent.currentShape.length === 0) {
                    parent.currentShape.push([endX, endY]);
                }
                else if (parent.currentShape.length === 0) {
                    parent.currentShape.push([endX, endY]);
                }
                else {
                    let firstPoint = parent.currentShape[0];
                    parent.currentShape = [];
                    parent.currentShape.push(firstPoint);
                    parent.currentShape.push([endX, endY]);
                }
            }

        } else if (parent.shapeType === "Ellipse") {
            let centerX = (parent.startX + endX) / 2;
            let centerY = (parent.startY + endY) / 2;
            let radiusX = Math.abs(endX - parent.startX) / 2;
            let radiusY = Math.abs(endY - parent.startY) / 2;
            parent.currentShape = [];
            for (let angle = 0; angle < 2 * Math.PI; angle += 0.01) {
                parent.currentShape.push([
                    centerX + radiusX * Math.cos(angle),
                    centerY + radiusY * Math.sin(angle)
                ]);
            }
            parent.currentShape.push(parent.currentShape[0]); // Close the shape
        } else if (parent.shapeType === "Rectangle") {
            parent.currentShape = [
                [parent.startX, parent.startY],
                [endX, parent.startY],
                [endX, endY],
                [parent.startX, endY],
                [parent.startX, parent.startY]
            ];
        } else if (parent.shapeType === "SprayCan") {
            let radius = parent.brushRadius;
            let density = parent.sprayDensity;
            let startX = endX - radius;
            let endXCoord = endX + radius;
            let startY = endY - radius;
            let endYCoord = endY + radius;
            for (let ix = startX; ix <= endXCoord; ix++) {
                for (let iy = startY; iy <= endYCoord; iy++) {
                    let dx = ix - endX;
                    let dy = iy - endY;
                    let distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance <= radius) {
                        let threshold = (1 - distance / radius) * density;
                        if (Math.random() < threshold) {
                            parent.currentShape.push([ix, iy, 1]); // Save spray can points
                        }
                    }
                }
            }
        } else if (parent.shapeType === "Brush") {
            let radius = parent.brushRadius;
            let newPoints = [];
            for (let angle = 0; angle < 2 * Math.PI; angle += Math.PI / 8) { // 16 points per circle
                let ix = endX + radius * Math.cos(angle);
                let iy = endY + radius * Math.sin(angle);
                newPoints.push([Math.round(ix), Math.round(iy)]);
            }

            // Add the center point of each circle
            newPoints.push([endX, endY]);

            if (parent.currentShape.length > 0) {
                let lastPoints = parent.currentShape[parent.currentShape.length - 1];
                if (lastPoints.length === newPoints.length) {
                    for (let i = 0; i < lastPoints.length; i++) {
                        let startX = lastPoints[i][0];
                        let startY = lastPoints[i][1];
                        let endX = newPoints[i][0];
                        let endY = newPoints[i][1];

                        if (!isNaN(startX) && !isNaN(startY) && !isNaN(endX) && !isNaN(endY)) {
                            // Add the original points
                            parent.currentShape.push([startX, startY, endX, endY]);

                            // Add points at 1/4, 1/2, and 3/4 of the way along the line
                            let quarterX1 = startX + 0.25 * (endX - startX);
                            let quarterY1 = startY + 0.25 * (endY - startY);
                            let halfX = startX + 0.5 * (endX - startX);
                            let halfY = startY + 0.5 * (endY - startY);
                            let quarterX3 = startX + 0.75 * (endX - startX);
                            let quarterY3 = startY + 0.75 * (endY - startY);

                            if (!isNaN(quarterX1) && !isNaN(quarterY1) && !isNaN(halfX) && !isNaN(halfY) && !isNaN(quarterX3) && !isNaN(quarterY3)) {
                                parent.currentShape.push([startX, startY, quarterX1, quarterY1]);
                                parent.currentShape.push([quarterX1, quarterY1, halfX, halfY]);
                                parent.currentShape.push([halfX, halfY, quarterX3, quarterY3]);
                                parent.currentShape.push([quarterX3, quarterY3, endX, endY]);
                            }
                        }
                    }
                }
            }
            parent.currentShape.push(newPoints);
        }

        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        let dx = adjustedX - parent.startX;
        let dy = adjustedY - parent.startY;
        parent.shapes[parent.activeShapeIndex] = parent.originalShape.map(point => [point[0] + dx, point[1] + dy]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        let currentAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], adjustedX, adjustedY);
        let angleDifference = currentAngle - parent.initialAngle;
        let currentDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter[0], parent.transformCenter[1]);
        let scale = currentDistance / parent.initialDistance;
        parent.shapes[parent.activeShapeIndex] = parent.transformShape(parent.originalShape, angleDifference, scale, scale, parent.transformCenter[0], parent.transformCenter[1]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.dragging) {
        let dx = (parent.dragOrigin.x - x) / zoomFactor;
        let dy = (parent.dragOrigin.y - y) / zoomFactor;
        parent.scrollPosition = new Point(parent.scrollPosition.x + dx, parent.scrollPosition.y + dy);
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        if (parent.viewport) {
            parent.viewport.update();
        }
    }
};



this.viewport.onMouseRelease = function (x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;

    calculateLineAngle = function (p1, p2) {
        const dy = p2[1] - p1[1];
        const dx = p2[0] - p1[0];

        // Calculate the angle in radians using Math.atan2()
        const angleRadians = Math.atan2(dy, dx);

        // Convert radians to degrees
        let angleDegrees = angleRadians * (180 / Math.PI);

        // Optional: Adjust the angle to be in the range [0, 360) if desired
        /*
        if (angleDegrees < 0) {
            angleDegrees += 360;
        }
        */
        return angleDegrees;
    }

    if (parent.isDrawing) {
        parent.isDrawing = false;
        if ((parent.shapeType === "Freehand") && (RSParameters.currentMode === MODE_REGION_SELECT)) {
            parent.currentShape.push([adjustedX, adjustedY]);
            parent.currentShape.push(parent.currentShape[0]); // Close the shape
        }

        if ((parent.shapeType === "Freehand") && (RSParameters.currentMode === MODE_ANGLE_SELECT)) {
            if (parent.currentShape.length === 0) {
                parent.currentShape.push([adjustedX, adjustedY]);
                Console.warningln('Only 1 point in the angle list on release');
                return;
            }
            else if (parent.currentShape.length === 1) {
                parent.currentShape.push([adjustedX, adjustedY]);
            }
            else {
                let firstPoint = parent.currentShape[0];
                parent.currentShape = [];
                parent.currentShape.push(firstPoint);
                parent.currentShape.push([adjustedX, adjustedY]);
            }
        }

        // Finalize the shape and ensure no extraneous points are added
        parent.shapes.push(parent.currentShape.filter(point => !isNaN(point[0]) && !isNaN(point[1])));
        parent.shapeTypes.push(parent.shapeType); // Save the shape type
        parent.currentShape = [];
        parent.activeShapeIndex = parent.shapes.length - 1; // Set the newly drawn shape as the active shape
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        parent.isMoving = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        parent.isTransforming = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else {
        this.cursor = new Cursor(StdCursor_Cross);
        parent.dragging = false;
    }

    if ((parent.shapeType === "Freehand") && (RSParameters.currentMode === MODE_ANGLE_SELECT)) {
        // if (parent.currentShape.length === 2) {
            // Calculate the angle
        let firstPoint = parent.shapes[parent.activeShapeIndex][0];
        let secondPoint = parent.shapes[parent.activeShapeIndex][1];

        let lineAngle = calculateLineAngle(firstPoint, secondPoint) + 90;

        Console.warningln('Line Angle is: ' + lineAngle);

        RSParameters.angle = lineAngle;
        // }
    }
};



this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent

    if (!parent.displayImage) {
        console.error("No display image set.");
        return;
    }

    let oldZoomFactor = parent.zoomFactor;

    // Calculate the old scroll position percentage
    let maxHorizontalScroll = (parent.displayImage.width * oldZoomFactor) - parent.viewport.width;
    let maxVerticalScroll = (parent.displayImage.height * oldZoomFactor) - parent.viewport.height;
    let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

    // Update the zoom factor based on the wheel delta
    if (delta > 0) {
        parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
    } else if (delta < 0) {
        parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
    }
    let newZoomFactor = parent.zoomFactor;

    // Reinitialize scrollbars to reflect the new zoom level
    parent.initScrollBars();

    // Calculate the new scroll position using the old scroll percentage
    maxHorizontalScroll = (parent.displayImage.width * newZoomFactor) - parent.viewport.width;
    maxVerticalScroll = (parent.displayImage.height * newZoomFactor) - parent.viewport.height;
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    // Ensure the new scroll position stays within valid bounds
    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    // Update the scroll position to keep the same relative position
    parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    parent.viewport.update();
};

// Zoom In Function
this.zoomIn = function() {
    this.zoomFactor = Math.min(this.zoomFactor * 1.25, this.maxZoomFactor);
    this.initScrollBars();
    if (this.viewport) {
        this.viewport.update();
    }
};

// Zoom Out Function
this.zoomOut = function() {
    this.zoomFactor = Math.max(this.zoomFactor * 0.8, this.minZoomFactor);
    this.initScrollBars();
    if (this.viewport) {
        this.viewport.update();
    }
};



// Updated onPaint with Gradient Start/End Points
this.viewport.onPaint = function(x0, y0, x1, y1) {
    var g = new Graphics(this);
    var result = this.parent.getImage();
    let zoomFactor = this.parent.zoomFactor;

    if (result == null) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
    } else {
        // Apply the scaling transformation
        g.scaleTransformation(zoomFactor);

        // Translate the image to account for scrolling
        g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);

        // Draw the image
        g.drawBitmap(0, 0, result.render());

        // Draw the user-defined shapes if they exist
        this.parent.shapes.forEach((shape, index) => {
            g.pen = new Pen(index === this.parent.activeShapeIndex ? 0xff00ff00 : 0xffff0000);
            /*
            if (RSParameters.currentMode === MODE_ANGLE_SELECT) {
                g.pen = new Pen(0x00ffff00);
            }
            else {
                g.pen = new Pen(index === this.parent.activeShapeIndex ? 0xff00ff00 : 0xffff0000);
            }
            */
            if (this.parent.shapeTypes[index] === "SprayCan" || this.parent.shapeTypes[index] === "Brush") {
                shape.forEach(point => {
                    if (Number.isFinite(point[0]) && Number.isFinite(point[1])) {
                        g.drawPoint(point[0], point[1]);
                    }
                });
            } else {
                for (let i = 0; i < shape.length - 1; i++) {
                    if (Number.isFinite(shape[i][0]) && Number.isFinite(shape[i][1]) && Number.isFinite(shape[i + 1][0]) && Number.isFinite(shape[i + 1][1])) {
                        g.drawLine(shape[i][0], shape[i][1], shape[i + 1][0], shape[i + 1][1]);
                    }
                }
            }
        });

        // Draw the current shape if it exists
        if (this.parent.currentShape.length > 0) {
            g.pen = new Pen(0xff00ff00);
            if (this.parent.shapeType === "SprayCan" || this.parent.shapeType === "Brush") {
                this.parent.currentShape.forEach(point => {
                    if (Number.isFinite(point[0]) && Number.isFinite(point[1])) {
                        g.drawPoint(point[0], point[1]);
                    }
                });
            } else {
                for (let i = 0; i < this.parent.currentShape.length - 1; i++) {
                    if (Number.isFinite(this.parent.currentShape[i][0]) && Number.isFinite(this.parent.currentShape[i][1]) && Number.isFinite(this.parent.currentShape[i + 1][0]) && Number.isFinite(this.parent.currentShape[i + 1][1])) {
                        g.drawLine(this.parent.currentShape[i][0], this.parent.currentShape[i][1],
                                   this.parent.currentShape[i + 1][0], this.parent.currentShape[i + 1][1]);
                    }
                }
            }
        }

// Draw gradient start and end points, if they exist
if (this.parent.gradientStartPoint) {
    g.pen = new Pen(0xff00ff00); // Green for start point
    g.brush = new Brush(0xff00ff00); // Solid green brush for filled circle
    g.drawCircle(this.parent.gradientStartPoint[0], this.parent.gradientStartPoint[1], 5); // Draw a small circle with radius 5
}
if (this.parent.gradientEndPoint) {
    g.pen = new Pen(0xffff0000); // Red for end point
    g.brush = new Brush(0xffff0000); // Solid red brush for filled circle
    g.drawCircle(this.parent.gradientEndPoint[0], this.parent.gradientEndPoint[1], 5); // Draw a small circle with radius 5
}

    }

    g.end();
    gc();
};






    this.setFocus = function() {
        this.viewport.onKeyPress = (keyCode, modifiers) => {
            if (keyCode === 0x20) { // Spacebar key
                this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
                this.viewport.update();
            }
        };
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

// Function to scale spray can points
ScrollControl.prototype.scaleSprayCanPoints = function(points, scaleRatio) {
    let scaledPoints = [];
    points.forEach(point => {
        let x = Math.round(point[0] * scaleRatio);
        let y = Math.round(point[1] * scaleRatio);
        if (!isNaN(x) && !isNaN(y)) { // Ensure coordinates are valid numbers
            // Create a region of points around the original point based on the scale ratio
            for (let dx = -Math.floor(scaleRatio / 2); dx <= Math.floor(scaleRatio / 2); dx++) {
                for (let dy = -Math.floor(scaleRatio / 2); dy <= Math.floor(scaleRatio / 2); dy++) {
                    let newX = x + dx;
                    let newY = y + dy;
                    if (newX >= 0 && newX < this.displayImage.width && newY >= 0 && newY < this.displayImage.height) {
                        scaledPoints.push([newX, newY]);
                    }
                }
            }
        } else {
            console.warningln("Invalid point detected during scaling: x=" + x + ", y=" + y);
        }
    });
    return scaledPoints;
};

// Function to scale brush points
ScrollControl.prototype.scaleBrushPoints = function(points, scaleRatio) {
    let scaledPoints = [];
    points.forEach(point => {
        let x = Math.round(point[0] * scaleRatio);
        let y = Math.round(point[1] * scaleRatio);
        if (!isNaN(x) && !isNaN(y)) { // Ensure coordinates are valid numbers
            scaledPoints.push([x, y]);
        } else {
            console.warningln("Invalid point detected during scaling: x=" + x + ", y=" + y);
        }
    });
    return scaledPoints;
};

// Function to scale all shapes when zoom changes
ScrollControl.prototype.scaleShapes = function(newZoomLevel) {
    try {
        let scaleRatio = this.previousZoomLevel / newZoomLevel;
        this.shapes = this.shapes.map((shape, index) => {
            if (this.shapeTypes[index] === "SprayCan") {
                return this.scaleSprayCanPoints(shape, scaleRatio);
            } else if (this.shapeTypes[index] === "Brush") {
                return this.scaleBrushPoints(shape, scaleRatio);
            } else {
                return shape.map(point => [
                    Math.round(point[0] * scaleRatio),
                    Math.round(point[1] * scaleRatio)
                ]);
            }
        });
        this.previousZoomLevel = newZoomLevel;
        if (this.viewport) {
            this.viewport.update();
        }
    } catch (error) {
        // Suppress any warnings or errors
        console.warningln("Error during shape scaling: " + error);
    }
};

// Ensure this function is called whenever the zoom level changes
RSDialog.prototype.updateZoomLevel = function(newZoomLevel) {
    if (this.previewControl) {
        this.previewControl.scaleShapes(newZoomLevel);
    }
};


function RSDialog() {
    this.__base__ = Dialog;
    this.__base__();
    this.maskType = "Binary";  // Initialize the maskType with a default value

    RSParameters.load();

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = SCRIPTNAME + " - " + VERSION;
    this.title_Lbl.textAlignment = TextAlign_Center;

    this.instructions_Lbl = new TextBox(this);
    this.instructions_Lbl.readOnly = true;
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.text = "Instructions:\n\nStep 1:\nShift + Click and drag to draw a shape around the artifact.\nSelect Create Mask from Selected Region to create the mask.\n\nStep 2:\nShift + Click to draw a line to select the angle of the streak artifact.\nSelect the feathering amount for the mask and the streak removal algorithm.\nSelect Remove Streaks using Selected Angle.\n\nStep 3:\nThe high frequency streaks should be gone, but optionally, the residual layers could be removed by selecting the upper and lower layers of an MMT filter to flatten the artifact to better match the background.\n\nCTRL+Click and Drag to MOVE the drawn shape.\nALT+Click and Drag to ROTATE and RESIZE\nGrey undo button removes the active shape\nRed Reset Button removes all shapes.";
    this.instructions_Lbl.setScaledMinWidth(450); // Set a fixed width for the instructions

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                RSParameters.targetWindow = window;
            }
        }
    }

    this.windowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
            if (window && !window.isNull) {
                RSParameters.targetWindow = window;
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                } else {
                    console.error("Selected image is undefined.");
                }
            } else {
                console.writeln("No valid window selected for preview!");
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };

    // Update this section to include the imageLabel
    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel); // Add the label to the sizer
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.shapeType = "Freehand"; // Default shape type

    var dlg = this;


    this.selectRegionButton = new PushButton(this);
    this.selectRegionButton.text = "Create Mask from Selected Region";
    this.selectRegionButton.toolTip = "Selects the region prior to the angle selector function.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.selectRegionButton.onClick = () => {
        console.writeln("Completing the region selection.");
        if (RSParameters.targetWindow) {
            let selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.generateMaskImage(selectedImage);

                RSParameters.shapes = [];
                // this.previewControl.viewport.update();
                this.previewControl.currentShape = [];
                this.previewControl.shapes = [];
                this.previewControl.doUpdateImage(this.previewControl.getImage());

                RSParameters.currentMode = MODE_ANGLE_SELECT;

                // this.viewport.update();
                this.selectRegionButton.enabled = false;
                this.selectAngleButton.enabled = true;
                this.featheringSlider.enabled = true;
                this.algorithmComboBox.enabled = true;

                var progress = 0.33;

                processEvents();
                dlg.progress(progress);

                dlg.lblState.text = 'Mask created - select angle of streaks using shift left mouse then remove';
                processEvents();
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    

    this.shapeSizer = new VerticalSizer;
    this.shapeSizer.spacing = 4;
    this.shapeSizer.add(this.selectRegionButton);
    
    this.selectAngleButton = new PushButton(this);
    this.selectAngleButton.text = "Remove Streaks using Selected Angle";
    this.selectAngleButton.toolTip = "Selects the angle direction of the streaks.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.selectAngleButton.onClick = () => {
        console.writeln("Completing the region selection.");
        if (RSParameters.targetWindow) {
            let selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                var algorithmNumber = RSParameters.selectedAlgorithm;
                // removeStreaksFromImage(RSParameters.targetWindow.mainView, dlg, algorithmNumber);
                // Console.warningln('Linear flag: ' + RSParameters.autoSTF);
                removeStreaksFromImageAsLinear(RSParameters.targetWindow.mainView, dlg, algorithmNumber, RSParameters.autoSTF);
                // this.generateMaskImage(selectedImage);

                var progress = 0.66;

                processEvents();
                dlg.progress(progress);

                dlg.lblState.text = 'Streaks removed - can flatten medium sized image structures further below';
                processEvents();
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.selectAngleButton.enabled = false;

    this.angleSelectionSizer = new HorizontalSizer;
    this.angleSelectionSizer.spacing = 4;
    this.angleSelectionSizer.add(this.selectAngleButton);


    this.featheringSlider = new NumericControl(this);
    this.featheringSlider.label.text = "Feathering amount: ";
    this.featheringSlider.setRange(0, 100);
    this.featheringSlider.slider.setRange(0, 100);
    this.featheringSlider.setValue(50); // Default value
    this.featheringSlider.toolTip = "Selects how smoothly the restored region is replaced into the original image.\n\nHigher numbers represent a smoother replacement.";

    this.featheringSlider.enabled = false;

    this.featheringSizer = new HorizontalSizer;
    this.featheringSizer.spacing = 4;
    this.featheringSizer.add(this.featheringSlider);


    this.algorithmLabel = new Label(this);
    this.algorithmLabel.text = "Algorithm: ";
    // this.algorithmLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.algorithmComboBox = new ComboBox(this);
    this.algorithmComboBox.addItem("Algorithm 1");
    this.algorithmComboBox.addItem("Algorithm 2");
    this.algorithmComboBox.currentItem = RSParameters.selectedAlgorithm;

    this.algorithmComboBox.enabled = false;

    // Add a variable to store the previous zoom level
    // RSParameters.selectedAlgorithm = this.algorithmComboBox.currentItem;

    this.algorithmComboBox.onItemSelected = (index) => {
        RSParameters.selectedAlgorithm = index;

        // Console.warningln('New selected algorithm index: ' + RSParameters.selectedAlgorithm);
    };

    this.algorithmSizer = new HorizontalSizer;
    this.algorithmSizer.spacing = 4;
    this.algorithmSizer.add(this.algorithmLabel);
    this.algorithmSizer.add(this.algorithmComboBox);


    this.lblState = new Label(this);
    this.lblState.text = "Awaiting region selection on image using shift left mouse button";

    this.lblStateSizer = new HorizontalSizer;
    this.lblStateSizer.spacing = 4;
    this.lblStateSizer.add(this.lblState);

    var progressValue = 0;

    this.progressBar = new Label(this);
    with (this.progressBar) {
        lineWidth = 1;
        frameStyle = FrameStyle_Box;
        textAlignment = TextAlign_Center | TextAlign_VertCenter;

        onPaint = function (x0, y0, x1, y1) {
            var g = new Graphics(dlg.progressBar);
            g.fillRect(x0, y0, x1, y1, new Brush(0xFFFFFFFF));
            if (progressValue > 0) {
                var l = (x1 - x0 + 1) * progressValue;
                g.fillRect(x0, y0, l, y1, new Brush(0xFF00EFE0));
            }
            g.end();
            text = (progressValue * 100).toFixed(0) + "%";
        }
    }

    this.progress = function (n) {
        progressValue = n;// Math.min(n, 1);
        dlg.progressBar.repaint();
    }


    this.lowerRangeSlider = new NumericControl(this);
    this.lowerRangeSlider.label.text = "Lower layers: ";
    this.lowerRangeSlider.setRange(1, MAX_LAYERS);
    this.lowerRangeSlider.slider.setRange(1, MAX_LAYERS);
    this.lowerRangeSlider.setValue(6); // Default value
    this.lowerRangeSlider.toolTip = "Selects the range of lower (smaller structure) layers to be kept for the MMT layer filtering.\nThe type of local structures within the artifact region would influence this number.\nReducing this number means reducing the number of layers retained.";
    this.lowerRangeSlider.onValueUpdated = function (value) {
        var upperRange = this.upperRangeSlider.value;

        if (value > upperRange - 1) {
            this.upperRangeSlider.setValue(value + 1);
        }

        if (value > MAX_LAYERS - 1) {
            this.lowerRangeSlider.setValue(MAX_LAYERS - 1);
        }
    }.bind(this);

    this.lowerRangeSizer = new HorizontalSizer;
    this.lowerRangeSizer.spacing = 4;
    this.lowerRangeSizer.add(this.lowerRangeSlider);

    this.upperRangeSlider = new NumericControl(this);
    this.upperRangeSlider.label.text = "Upper layers: ";
    this.upperRangeSlider.setRange(1, MAX_LAYERS);
    this.upperRangeSlider.slider.setRange(1, MAX_LAYERS);
    this.upperRangeSlider.setValue(10); // Default value
    this.upperRangeSlider.toolTip = "Selects the range of upper (larger structure) layers to be kept.";
    this.upperRangeSlider.onValueUpdated = function (value) {
        var lowerRange = this.lowerRangeSlider.value;

        if (value < lowerRange + 1) {
            this.lowerRangeSlider.setValue(value - 1);
        }

        if (value < 2) {
            this.upperRangeSlider.setValue(2);
        }
    }.bind(this);

    this.upperRangeSizer = new HorizontalSizer;
    this.upperRangeSizer.spacing = 4;
    this.upperRangeSizer.add(this.upperRangeSlider);

    this.flattenResidualButton = new PushButton(this);
    this.flattenResidualButton.text = "Flatten Residual Layers";
    this.flattenResidualButton.toolTip = "Removes selected layer range using MMT.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.flattenResidualButton.onClick = () => {
        console.writeln("Flattening the selected region.");
        if (RSParameters.targetWindow) {
            let selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                flattenResidualFromImage(RSParameters.targetWindow.mainView, dlg);
                // this.generateMaskImage(selectedImage);

                var progress = 1.0;

                processEvents();
                dlg.progress(progress);

                dlg.lblState.text = 'Image further flattened';
                processEvents();
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.flattenResidualButton.enabled = true;

    this.flattenResidualSizer = new HorizontalSizer;
    this.flattenResidualSizer.spacing = 4;
    this.flattenResidualSizer.add(this.flattenResidualButton);
   

    // Add the AutoSTF checkbox
    this.autoSTF_Cb = new CheckBox(this);
    this.autoSTF_Cb.text = "Process as linear";
    this.autoSTF_Cb.checked = RSParameters.autoSTF;
    this.autoSTF_Cb.onCheck = () => {
        if (RSParameters.targetWindow) {
            var selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            }
        }

        RSParameters.autoSTF = this.autoSTF_Cb.checked;

        // Console.warningln('Linear flag: ' + RSParameters.autoSTF);
    };

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Preview Zoom Level: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.zoomLevelComboBox = new ComboBox(this);
    this.zoomLevelComboBox.addItem("1:1");
    this.zoomLevelComboBox.addItem("1:2");
    this.zoomLevelComboBox.addItem("1:4");
    this.zoomLevelComboBox.addItem("1:8");
    this.zoomLevelComboBox.addItem("Fit to Preview");
    this.zoomLevelComboBox.currentItem = 1;

    // Add a variable to store the previous zoom level
    this.previousZoomLevel = this.zoomLevelComboBox.currentItem;

    this.zoomLevelComboBox.onItemSelected = (index) => {
        if (RSParameters.targetWindow) {
            var selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Adjusting preview for image with ID: " + RSParameters.targetWindow.mainView.id);
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();

                // Scale shapes according to the new zoom level
                let newZoomLevel = this.downsamplingFactor;
                this.scaleShapes(newZoomLevel);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for preview!");
        }
    };

    this.resetButton = new ToolButton(this);
    this.resetButton.icon = this.scaledResource(":/icons/execute.png"); // Updated to use the red lightning bolt icon
    this.resetButton.toolTip = "Reset selections";
    this.resetButton.onMousePress = () => {
        this.previewControl.shapes = [];
        this.previewControl.viewport.update();
            // Reset gradient start and end points
    this.previewControl.gradientStartPoint = null;
    this.previewControl.gradientEndPoint = null;
    };

    this.undoButton = new ToolButton(this);
    this.undoButton.icon = this.scaledResource(":/icons/reload.png"); // Updated to use the grey icon for undo
    this.undoButton.toolTip = "Undo last shape";
    this.undoButton.onMousePress = () => {
        if (this.previewControl.shapes.length > 0) {
            // Remove the active shape
            this.previewControl.shapes.splice(this.previewControl.activeShapeIndex, 1);

            // Adjust activeShapeIndex
            if (this.previewControl.shapes.length === 0) {
                this.previewControl.activeShapeIndex = 0; // Reset to 0 if no shapes are left
            } else {
                this.previewControl.activeShapeIndex = this.previewControl.activeShapeIndex % this.previewControl.shapes.length;
            }

            this.previewControl.viewport.update();
        }
    };

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 4;
    this.zoomSizer.add(this.autoSTF_Cb); // Add the AutoSTF checkbox to the sizer
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.add(this.zoomLevelComboBox);
    this.zoomSizer.add(this.undoButton); // Add the undo button next to the zoom control
    this.zoomSizer.add(this.resetButton); // Add the reset button next to the zoom control

    // Define the label for the authorship information
    this.authorship_Lbl = new Label(this);
    this.authorship_Lbl.frameStyle = FrameStyle_Box;
    this.authorship_Lbl.margin = 6;
    this.authorship_Lbl.useRichText = true;
    this.authorship_Lbl.text = "Written by Chick Dee<br>Other scripts here: <a href=\"http://github.com/chickadeebird\">github.com/chickadeebird</a>";
    this.authorship_Lbl.textAlignment = TextAlign_Center;

    // Wrench Icon Button for setting the SetiAstroDenoise parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function () {
        let pathDialog = new GetDirectoryDialog;
        // let pathDialog = new OpenFileDialog;
        pathDialog.initialPath = RSParameters.RSPythonToolsParentFolderPath;
        if (pathDialog.execute()) {
            RSParameters.RSPythonToolsParentFolderPath = pathDialog.directory;
            Console.writeln('Operating folder path: ' + RSParameters.RSPythonToolsParentFolderPath);
            RSParameters.save();
            // this.parent.correctionFileLabel.text = RSParameters.RSPythonToolsParentFolderPath;


        }
    };

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current RSParameters.";
    this.newInstance_Btn.onMousePress = () => {
        RSParameters.save();
        this.newInstance();
    };

    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Remove Streaks";
    this.execute_Btn.toolTip = "Remove streaks from the selected region.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.execute_Btn.onClick = () => {
        console.writeln("Executing the script with the selected RSParameters.");
        if (RSParameters.targetWindow) {
            let selectedImage = RSParameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.generateMaskImage(selectedImage);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 6;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.add(this.setupButton);
    this.buttonSizerHorizontal.addStretch();
    this.buttonSizerHorizontal.add(this.execute_Btn);

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);


// Zoom In Button
this.zoomInButton = new PushButton(this);
this.zoomInButton.text = "";
this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
this.zoomInButton.toolTip = "Zoom In";
this.zoomInButton.onClick = () => {
    this.previewControl.zoomIn();
};

// Zoom Out Button
this.zoomOutButton = new PushButton(this);
this.zoomOutButton.text = "";
this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
this.zoomOutButton.toolTip = "Zoom Out";
this.zoomOutButton.onClick = () => {
    this.previewControl.zoomOut();
};

// Zoom Label
this.zoomLabel = new Label(this);
this.zoomLabel.text = "Zoom In/Out (Mouse Wheel Supported)";

// Zoom Sizer
this.zoomSizer2 = new HorizontalSizer;
this.zoomSizer2.spacing = 6;
this.zoomSizer2.add(this.zoomInButton);
this.zoomSizer2.add(this.zoomOutButton);
this.zoomSizer2.add(this.zoomLabel);
this.zoomSizer2.addStretch();


// Create a vertical sizer to hold the label and the previewControl
this.previewSizer = new VerticalSizer;
this.previewSizer.spacing = 4;
this.previewSizer.add(this.zoomSizer2);  // Add zoomSizer for buttons
this.previewSizer.add(this.previewControl, 1);

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 4;

    // Define a spacer control with a fixed width
    this.leftSideSpacer = new Control(this);
    this.leftSideSpacer.setFixedWidth(5); // Adjust the width as needed

    // Insert the spacer control at the beginning of the mainSizer
    this.mainSizer.insert(0, this.leftSideSpacer);
    this.mainSizer.addSpacing(0); // Add some spacing after the spacer

    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;
    this.leftSizer.add(this.title_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.instructions_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.imageSelectionSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.shapeSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.featheringSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.angleSelectionSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.algorithmSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.lowerRangeSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.upperRangeSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.flattenResidualSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.zoomSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.authorship_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.lblStateSizer);
    this.leftSizer.spacing = 8;
    this.leftSizer.add(this.progressBar);
    this.leftSizer.spacing = 6;
    this.leftSizer.add(this.buttonSizerHorizontal);

// Create a control to fix the width of the left panel
this.leftPanel = new Control(this);
this.leftPanel.sizer = this.leftSizer;
this.leftPanel.setFixedWidth(450); // Adjust this value as needed

// Add the leftSizer and the previewSizer to the mainSizer
this.mainSizer.add(this.leftPanel);
this.mainSizer.add(this.previewSizer);

    this.sizer = this.mainSizer;

    this.windowTitle = SCRIPTNAME;
    this.adjustToContents();

    // Add key event listener
    this.onKeyDown = function(keyCode, modifiers) {
        if (keyCode === 0x20) { // Spacebar key
            if (this.previewControl.shapes.length > 0) {
                this.previewControl.activeShapeIndex = (this.previewControl.activeShapeIndex + 1) % this.previewControl.shapes.length;
                this.previewControl.viewport.update();
            }
        }
    }.bind(this);

    // Ensure the initial display setup calls the correct function
    this.onShow = () => {
        if (this.windowSelector_Cb.currentItem >= 0) { // Adjust for "Select Image:" item
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
            if (window && !window.isNull) {
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the initial image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();

                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                }
            }
        } else {
            console.noteln("No image selected for preview.");
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents(); // Adjust the dialog size to fit the initial content
        }

        this.previewControl.setFocus(); // Set focus to handle key events
    };

    // Add a variable to store the downsampling factor
    //this.downsamplingFactor = 1;

    // Function to scale shapes according to the new zoom level
    this.scaleShapes = function(newZoomLevel) {
        try {
            let scaleRatio = this.previousZoomLevel / newZoomLevel;
            this.previewControl.shapes = this.previewControl.shapes.map(shape => shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]));
            this.previousZoomLevel = newZoomLevel;
            if (this.previewControl.viewport) {
                this.previewControl.viewport.update();
            }
        } catch (error) {
            // Suppress any warnings or errors
        }
    };

    // Function to create, resize, and display a temporary image
    this.createAndDisplayTemporaryImage = function(selectedImage) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

        if (this.autoSTF_Cb.checked) {
            var P = new PixelMath;
            P.expression =
                "C = -2.8  ;\n" +
                "B = 0.20  ;\n" +
                "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
            P.expression1 = "";
            P.expression2 = "";
            P.expression3 = "";
            P.useSingleExpression = true;
            P.symbols = "C,B,c";
            P.clearImageCacheAndExit = false;
            P.cacheGeneratedImages = false;
            P.generateOutput = true;
            P.singleThreaded = false;
            P.optimization = true;
            P.use64BitWorkingImage = false;
            P.rescale = false;
            P.rescaleLower = 0;
            P.rescaleUpper = 1;
            P.truncate = true;
            P.truncateLower = 0;
            P.truncateUpper = 1;
            P.createNewImage = false;
            P.showNewImage = true;
            P.newImageId = "";
            P.newImageWidth = 0;
            P.newImageHeight = 0;
            P.newImageAlpha = false;
            P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
            P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
            P.executeOn(window.mainView);
        }

        var P = new IntegerResample;
        switch (this.zoomLevelComboBox.currentItem) {
            case 0: // 1:1
                P.zoomFactor = -1;
                this.downsamplingFactor = 1;
                break;
            case 1: // 1:2
                P.zoomFactor = -2;
                this.downsamplingFactor = 2;
                break;
            case 2: // 1:4
                P.zoomFactor = -4;
                this.downsamplingFactor = 4;
                break;
            case 3: // 1:8
                P.zoomFactor = -8;
                this.downsamplingFactor = 8;
                break;
            case 4: // Fit to Preview
                const previewWidth = this.previewControl.width;
                const widthScale = Math.floor(selectedImage.width / previewWidth);
                P.zoomFactor = -Math.max(widthScale, 1);
                this.downsamplingFactor = Math.max(widthScale, 1);
                break;
            default:
                P.zoomFactor = -2; // Default to 1:2 if nothing is selected
                this.downsamplingFactor = 2;
                break;
        }

        P.executeOn(window.mainView);

        let resizedImage = new Image(window.mainView.image);

        if (resizedImage.width > 0 && resizedImage.height > 0) {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage(resizedImage);
            this.previewControl.initScrollBars();
        } else {
            console.error("Resized image has invalid dimensions.");
        }

        window.forceClose();

        return resizedImage;
    };
}
RSDialog.prototype = new Dialog;


// Update mask generation logic to handle the "Color" mask type
function getColorRange(color) {
    switch (color) {
        case "Red":
            return { min: 330, max: 40 }; // Adjusted to be narrower in the orange region
        case "Yellow":
            return { min: 40, max: 85 }; // Adjusted to be narrower in the red region
        case "Green":
            return { min: 85, max: 160 }; // Kept as is
        case "Cyan":
            return { min: 160, max: 200 }; // Kept as is
        case "Blue":
            return { min: 200, max: 270 }; // Kept as is
        case "Magenta":
            return { min: 270, max: 330 }; // Extended into the purple region
        default:
            return { min: 0, max: 0 }; // Default to no range
    }
}

RSDialog.prototype.generateMaskImage = function(selectedImage) {
    console.noteln("Mask Creation Started!");
    console.flush();

    let self = this; // Store reference to 'this'

    let gradientStartPoint = this.previewControl.gradientStartPoint;
    let gradientEndPoint = this.previewControl.gradientEndPoint;

    // Check if the image is a mono image
    if (selectedImage.numberOfChannels < 3 && this.maskType === "Color") {
        (new MessageBox("Cannot create a Color Mask from a mono image.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    // Create a new grayscale image with the same dimensions as the original image
    let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let maskImageView = maskWindow.mainView;
    maskImageView.beginProcess(UndoFlag_NoSwapFile);
    let maskImage = maskImageView.image;
    maskImage.fill(0); // Initialize the mask image with black (0)

    // Scale shapes according to the full-size image dimensions
    let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image

    // Function to find the minimum and maximum y-coordinates in the polygon
    function findMinMaxY(polygon) {
        let minY = polygon[0][1];
        let maxY = polygon[0][1];
        for (let i = 1; i < polygon.length; i++) {
            if (polygon[i][1] < minY) minY = polygon[i][1];
            if (polygon[i][1] > maxY) maxY = polygon[i][1];
        }
        return { minY: minY, maxY: maxY };
    }

    // Function to calculate the linear interpolation between two points for the gradient
    function interpolateGradient(x, y, startX, startY, endX, endY) {
        let dx = endX - startX;
        let dy = endY - startY;
        let length = Math.sqrt(dx * dx + dy * dy); // Calculate the actual distance (length)

        // Avoid division by zero
        if (length === 0) {
            return 0;
        }

        // Compute the vector from the start point to the current point
        let vx = x - startX;
        let vy = y - startY;

        // Compute the dot product of the vector (vx, vy) with the direction vector (dx, dy)
        let dotProduct = (vx * dx + vy * dy) / length;

        // Normalize the dot product to get t in the range [0, 1]
        let t = dotProduct / length;

        // Clamp the value between 0 and 1 to ensure the gradient doesn't go beyond the endpoints
        return Math.max(0, Math.min(1, t));
    }



    // Function to fill a polygon using the scan-line filling algorithm
    function fillPolygon(image, polygon) {
        let { minY, maxY } = findMinMaxY(polygon);

        for (let y = minY; y <= maxY; y++) {
            if (y < 0 || y >= image.height) continue; // Skip out-of-bounds y-coordinates
            let intersections = [];
            for (let i = 0; i < polygon.length; i++) {
                let j = (i + 1) % polygon.length;
                let x1 = polygon[i][0], y1 = polygon[i][1];
                let x2 = polygon[j][0], y2 = polygon[j][1];

                if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) {
                    let x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                    intersections.push(Math.round(x));
                }
            }
            intersections.sort((a, b) => a - b);

            for (let k = 0; k < intersections.length; k += 2) {
                let xStart = Math.max(intersections[k], 0);
                let xEnd = Math.min(intersections[k + 1], image.width - 1);
                for (let x = xStart; x <= xEnd; x++) {
                    if (self.maskType === "Binary") {
                        image.setSample(1, x, y, 0); // Set the pixel to white (1) for binary mask
                    } else if (self.maskType === "Lightness") {
                        let brightness = selectedImage.sample(x, y, 0); // Get the brightness value
                        image.setSample(brightness, x, y, 0); // Set the pixel to brightness value for lightness mask
                    } else if (self.maskType === "Chrominance") {
                        if (selectedImage.numberOfChannels < 3) {
                            console.warningln("Cannot Create a Chrominance Mask of a Grey Scale Image!!!");
                            return;
                        }
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let maxChannel = Math.max(r, g, b);
                        let minChannel = Math.min(r, g, b);
                        let chrominance = (maxChannel - minChannel) / maxChannel; // Calculate chrominance value
                        if (isNaN(chrominance)) chrominance = 0;
                        image.setSample(chrominance, x, y, 0); // Set the pixel to chrominance value for chrominance mask
                    } else if (self.maskType === "Color") {
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let hue = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
                        if (hue < 0) hue += 360;
                        let { min, max } = getColorRange(self.colorDropdown.itemText(self.colorDropdown.currentItem));
                        let colorValue = (min < max)
                            ? (hue >= min && hue <= max ? 1 : 0)
                            : ((hue >= min || hue <= max) ? 1 : 0);
                        let chrominance = (Math.max(r, g, b) - Math.min(r, g, b)) / Math.max(r, g, b); // Calculate chrominance value
                        let sampleValue = colorValue * chrominance; // Scale color value by chrominance
                        if (isNaN(sampleValue)) sampleValue = 0; // Replace NaN with 0
                        image.setSample(sampleValue, x, y, 0); // Scale color value by chrominance
                    } else if (self.maskType === "Gradient") {
    // Scale the gradient start and end points by scaleRatio
    let scaledStartX = gradientStartPoint[0] * scaleRatio;
    let scaledStartY = gradientStartPoint[1] * scaleRatio;
    let scaledEndX = gradientEndPoint[0] * scaleRatio;
    let scaledEndY = gradientEndPoint[1] * scaleRatio;

    // Calculate gradient value for the current pixel within the polygon
    let gradientValue = interpolateGradient(
        x, y,
        scaledStartX, scaledStartY,
        scaledEndX, scaledEndY
    );
    image.setSample(gradientValue, x, y, 0); // Set pixel value to gradient value
}
                }
            }
        }
    }

    // Function to draw thick polylines
    function drawBrushStrokes(image, strokes, thickness, scaleRatio) {
        strokes = strokes.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        thickness = thickness * scaleRatio; // Scale the thickness
        for (let i = 0; i < strokes.length - 1; i++) {
            let p1 = strokes[i];
            let p2 = strokes[i + 1];
            let dx = p2[0] - p1[0];
            let dy = p2[1] - p1[1];
            let length = Math.sqrt(dx * dx + dy * dy);
            let offsetX = -dy / length * thickness / 2;
            let offsetY = dx / length * thickness / 2;

            let polyline = [
                [p1[0] + offsetX, p1[1] + offsetY],
                [p1[0] - offsetX, p1[1] - offsetY],
                [p2[0] - offsetX, p2[1] - offsetY],
                [p2[0] + offsetX, p2[1] + offsetY]
            ];

            fillPolygon(image, polyline);
        }
    }

    // Function to draw spray can points directly onto the mask image
    function drawSprayCanPoints(image, strokes) {
        strokes.forEach(point => {
            let x = point[0];
            let y = point[1];
            if (x >= 0 && x < image.width && y >= 0 && y < image.height) {
                image.setSample(1, x, y, 0); // Set the pixel value to 1 for spray can points
            }
        });
    }

    // Function to scale spray can points according to the full-size image dimensions
    function scaleSprayCanPoints(points, scaleRatio) {
        let scaledPoints = [];
        points.forEach(point => {
            let x = Math.round(point[0] * scaleRatio);
            let y = Math.round(point[1] * scaleRatio);
            for (let dx = 0; dx < scaleRatio; dx++) {
                for (let dy = 0; dy < scaleRatio; dy++) {
                    scaledPoints.push([x + dx, y + dy]);
                }
            }
        });
        return scaledPoints;
    }

    // Fill the mask image with the appropriate values inside the user-defined shapes
    this.previewControl.shapes.forEach((shape, index) => {
        let scaledShape = shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        if (self.previewControl.shapeTypes[index] === "Brush") {
            drawBrushStrokes(maskImage, shape, self.previewControl.brushRadius, scaleRatio);
        } else if (self.previewControl.shapeTypes[index] === "SprayCan") {
            let scaledSprayCanPoints = scaleSprayCanPoints(shape, scaleRatio);
            drawSprayCanPoints(maskImage, scaledSprayCanPoints);
        } else {
            fillPolygon(maskImage, scaledShape);
        }
    });

    maskImageView.endProcess();

    // Set mask window ID based on mask type
    let maskSuffix = "";
    if (this.maskType === "Binary") {
        maskSuffix = "_bin";
    } else if (this.maskType === "Lightness") {
        maskSuffix = "_lght";
    } else if (this.maskType === "Chrominance") {
        maskSuffix = "_chrm";
    } else if (this.maskType === "Color") {
        maskSuffix = "_color";
    } else if (self.gradientMask_Cb && self.gradientMask_Cb.checked) {
        maskSuffix = "_gradient";
    }

    maskImageView.id = RSParameters.targetWindow.mainView.id + "_RS_Mask" + maskSuffix;
    maskWindow.show();

    // Apply convolution to blur the mask image

    var blurAmount = this.featheringSlider.value;
    // var blurAmount = 100;
    if (blurAmount > 0) {
        var P = new Convolution;
        P.mode = Convolution.prototype.Parametric;
        P.sigma = blurAmount;
        P.executeOn(maskImageView);
    } else {
        console.writeln("Skipping convolution as blurAmount is 0.");
        console.flush();
    }

    RSParameters.maskWindow = maskWindow;
};


function main() {
    console.show();
    Console.warningln("                  .-.");
    Console.warningln("                 (  `>");
    Console.warningln("                 /  \\");
    Console.warningln("                /  \\ |");
    Console.warningln("               / ,_//");
    Console.warningln("      ~~~~~~~~//`--`~~~~~~~");
    Console.warningln("      ~~~~~~~//~~~~~~~~~~~");
    Console.warningln("            `");
    Console.criticalln("      Chickadee Scripts - " + SCRIPTNAME);
    console.flush();
    let dialog = new RSDialog();
    dialog.execute();
}

main();

function saveImageAsXISF(inputFolderPath, view) {
    // Obtain the ImageWindow object from the view's main window
    let imgWindow = view.isMainView ? view.window : view.mainView.window;

    if (!imgWindow) {
        throw new Error("Image window is undefined for the specified view.");
    }

    let fileName = imgWindow.mainView.id;  // Get the main view's id as the filename
    let filePath = inputFolderPath + pathSeparator + fileName + ".xisf";

    // Set the image format to 32-bit float if not already set
    imgWindow.bitsPerSample = 32;
    imgWindow.ieeefpSampleFormat = true;

    // Save the image in XISF format
    if (!imgWindow.saveAs(filePath, false, false, false, false)) {
        throw new Error("Failed to save image as 32-bit XISF: " + filePath);
    }

    console.writeln("Image saved as 32-bit XISF: " + filePath);
    return filePath;
}



// Function to wait for the output file indefinitely
function waitForFile(outputFilePath) {
    let pollingInterval = 1000;  // Poll every 1 second
    let postFindDelay = 2000;    // Delay of 2 seconds after finding the file

    console.writeln("Waiting for output file: " + outputFilePath);
    // Keep looping until the file exists
    while (!File.exists(outputFilePath)) {
        msleep(pollingInterval);
    }

    console.writeln("Output file found: " + outputFilePath);
    console.writeln("Waiting for " + (postFindDelay / 1000) + " seconds to ensure the file is completely saved.");
    msleep(postFindDelay);

    return true;
}




// Process the denoised image after waiting for it
function processOutputImage(outputFilePath, targetView) {
    if (!File.exists(outputFilePath)) {
        console.criticalln("Denoised file not found: " + outputFilePath);
        return;
    }

    let denoisedWindow = ImageWindow.open(outputFilePath)[0];
    if (denoisedWindow) {
        denoisedWindow.show();

        // Now apply PixelMath to replace the original image with the reverted, denoised image
        let pixelMath = new PixelMath;
        pixelMath.expression = "iif(" + denoisedWindow.mainView.id + " == 0, $T, " + denoisedWindow.mainView.id + "*" + RSParameters.maskWindow.mainView.id + "+" + targetView.id + "*(1-" + RSParameters.maskWindow.mainView.id + "))";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage = false;
        pixelMath.executeOn(targetView);  // Replace the target view (main image) with the denoised one

        

        // Close the denoised image window after PixelMath operation
        denoisedWindow.forceClose();

        // Try deleting the temporary denoised file
        try {
            File.remove(outputFilePath);
            console.writeln("Deleted restored file: " + outputFilePath);
        } catch (error) {
            console.warningln("Failed to delete restored file: " + outputFilePath);
        }
    } else {
        console.criticalln("Failed to open restored image: " + outputFilePath);
    }
}



// Function to delete the input file
function deleteInputFile(inputFilePath) {
    try {
        if (File.exists(inputFilePath)) {
            File.remove(inputFilePath);
            console.writeln("Deleted input file: " + inputFilePath);
        } else {
            console.warningln("Input file not found: " + inputFilePath);
        }
    } catch (error) {
        console.warningln("Failed to delete input file: " + inputFilePath);
    }
}

// Create batch file to run the denoise process
function createBatchFile(batchFilePath, exePath, inputFilePath, algorithmNumber) {
    let batchContent;

    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        batchContent = "#!/bin/sh\n";
        batchContent += "cd \"" + exePath + "\"\n";
        batchContent += 'osascript -e \'tell application "Terminal" to do script "' +
            exePath + "/Denoise ";  // Use the full path to the executable
        batchContent += "--algorithm " + algorithmNumber + " ";
        batchContent += "--angle " + RSParameters.angle + " ";
        batchContent += "--filename \"" + inputFilePath + "\"\n";
    } // Linux shell script
    else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        console.writeln("denoising : " + inputFilePath);
        batchContent = "@echo off\n";
        batchContent += "cd /d \"" + exePath + "\"\n";
        batchContent += "start RemoveStreaks.exe ";
        batchContent += "--algorithm " + algorithmNumber + " ";
        batchContent += "--angle " + RSParameters.angle + " ";
        batchContent += "--filename \"" + inputFilePath + "\"\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    // Write the script to the specified path
    try {
        File.writeTextFile(batchFilePath, batchContent);
        console.writeln((CoreApplication.platform == "Linux") ?
            "Shell script created: " + batchFilePath :
            "Batch file created: " + batchFilePath);
    } catch (error) {
        console.criticalln("Failed to create batch/shell file: " + error.message);
        return false;
    }

    console.writeln("Finished creating batch file.");

    return true;
}




function removeStreaksFromImage(view, dlg, algorithmNumber) {
    let inputFolderPath = RSParameters.RSPythonToolsParentFolderPath + pathSeparator + "working";
    let outputFolderPath = RSParameters.RSPythonToolsParentFolderPath + pathSeparator + "working";
    // let outputFolderPath = RSParameters.RSPythonToolsParentFolderPath;
    let outputFileName = view.id + "_restored.xisf";
    // let outputFileName = "Rotated_denoised.fits";
    let outputFilePath = outputFolderPath + pathSeparator + outputFileName;
    console.writeln("Output file path: " + outputFilePath);

    let inputFilePath = saveImageAsXISF(inputFolderPath, view);
    console.writeln("Input file path: " + inputFilePath);
    let batchFilePath = RSParameters.RSPythonToolsParentFolderPath + pathSeparator + "run_RemoveStreaksPython" + SCRIPT_EXT;

    let stars_only = false;

    if (createBatchFile(batchFilePath, RSParameters.RSPythonToolsParentFolderPath, inputFilePath, algorithmNumber)) {

        let process = new ExternalProcess;
        // return false;
        try {
            if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "Linux") {
                if (!process.start(CMD_EXEC, [batchFilePath])) {
                    console.writeln("RemoveStreaks started.");
                    console.flush();
                    console.writeln("RemoveStreaks finished inside loop.");
                }
            } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
                if (!process.start(CMD_EXEC, ["/c", batchFilePath])) {
                    console.writeln("RemoveStreaks started.");
                    console.flush();
                    console.writeln("RemoveStreaks finished inside loop.");
                }
            }
        } catch (error) {
            console.criticalln("Error starting process: " + error.message);
        }


        // process.start(CMD_EXEC, ["/c", batchFilePath]);
        console.flush();
        console.writeln("RemoveStreaksPython started.");
        console.flush();

        if (waitForFile(outputFilePath)) {
            processOutputImage(outputFilePath, view);
            deleteInputFile(inputFilePath);
        } else {
            console.criticalln("Output file not found within timeout.");
        }
    }

    dlg.lblState.text = 'Image restored';
    processEvents();


    return true;
}

function removeStreaksFromImageAsLinear(view, dlg, algorithmNumber, denoiseAsLinear) {
    let intermediateImageWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );

    let intermediateImageView = intermediateImageWindow.mainView;
    intermediateImageView.beginProcess(UndoFlag_NoSwapFile);
    let intermediateImageImage = intermediateImageView.image;
    intermediateImageImage.apply(view.image);

    intermediateImageWindow.show();

    if (denoiseAsLinear) {
        dlg.lblState.text = 'Applying temporary auto STF';
        processEvents();

        let constantCalcWindow = new ImageWindow(view.image.width, view.image.height,
            view.image.numberOfChannels, // 1 channel for grayscale
            view.image.bitsPerSample,
            view.image.isReal,
            view.image.isColor
        );

        let constantCalcView = constantCalcWindow.mainView;
        constantCalcView.beginProcess(UndoFlag_NoSwapFile);
        let constantCalcImage = constantCalcView.image;
        constantCalcImage.apply(view.image);

        var P = new PixelMath;
        P.expression =
            "C = -2.8  ;\n" +
            "B = 0.20  ;\n" +
            "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
            "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
        P.expression1 = "";
        P.expression2 = "";
        P.expression3 = "";
        P.useSingleExpression = true;
        P.symbols = "C,B,c";
        P.clearImageCacheAndExit = false;
        P.cacheGeneratedImages = false;
        P.generateOutput = true;
        P.singleThreaded = false;
        P.optimization = true;
        P.use64BitWorkingImage = false;
        P.rescale = false;
        P.rescaleLower = 0;
        P.rescaleUpper = 1;
        P.truncate = true;
        P.truncateLower = 0;
        P.truncateUpper = 1;
        P.createNewImage = false;
        P.showNewImage = true;
        P.newImageId = "";
        P.newImageWidth = 0;
        P.newImageHeight = 0;
        P.newImageAlpha = false;
        P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;


        P.expression =
            "C = -2.8  ;\n" +
            "B = 0.25  ;\n" +
            "min(max(0,med($T)+C*1.4826*mdev($T)),1);";

        P.executeOn(constantCalcView);

        var C0 = constantCalcImage.sample(0, 0);

        Console.writeln("C0: " + C0);

        constantCalcImage.apply(view.image);

        var targetBackground = 0.25;

        P.expression = "mtf(" + targetBackground + ",med($T) - " + C0 + ");";

        P.executeOn(constantCalcView);

        var mtfConstant = constantCalcImage.sample(0, 0);

        Console.writeln("mtfConstant: " + mtfConstant);



        // ****************** Start here with the input image after the constants have been calculated

        intermediateImageImage.apply(view.image);

        P.expression = "max(0, ($T - " + C0 + ")/~" + C0 + ");";

        P.executeOn(intermediateImageView);

        P.expression = "mtf((" + mtfConstant + "), $T);";

        P.executeOn(intermediateImageView);

        // ****************** Do the operations on the autoSTF image here

        // -------->

        constantCalcWindow.show();
        constantCalcWindow.forceClose();
        // autoSTFWindow.forceClose();
    }

    dlg.lblState.text = 'Denoising with supplied denoising convolutional neural network';
    processEvents();

    var denoiseReturn = removeStreaksFromImage(intermediateImageView, dlg, algorithmNumber);

    if (denoiseAsLinear) {
        dlg.lblState.text = 'Reversing auto STF';
        processEvents();

        // ****************** Now reverse out of the autoSTF

        P.expression = "mtf((1 - " + mtfConstant + "), $T);";

        P.executeOn(intermediateImageView);

        P.expression = "max(0, ($T * ~" + C0 + ") + " + C0 + ");";

        P.executeOn(intermediateImageView);
    }

    var P = new PixelMath;
    P.expression =
        "" + intermediateImageView.id + "";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "C,B,c";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    if (RSParameters.targetMaskWindow) {
        let maskView = View.viewById(dlg.maskSelectionDropdown.itemText(dlg.maskSelectionDropdown.currentItem));

        P.expression =
            "" + intermediateImageView.id + "*~" + maskView.id + "+" + view.id + "*" + maskView.id;

        P.executeOn(intermediateImageView);
    }





    P.expression =
        "" + intermediateImageView.id + "";

    P.executeOn(view);

    intermediateImageWindow.forceClose();

    return intermediateImageView;
}




function flattenResidualFromImage(view, dlg) {
    var PMMT = new MultiscaleMedianTransform;
    PMMT.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionAdaptive
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000], // row 10
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000]
    ];
    PMMT.transform = MultiscaleMedianTransform.prototype.MultiscaleMedianTransform;
    PMMT.medianWaveletThreshold = 5.00;
    PMMT.scaleDelta = 0;
    PMMT.linearMask = false;
    PMMT.linearMaskAmpFactor = 100;
    PMMT.linearMaskSmoothness = 1.00;
    PMMT.linearMaskInverted = true;
    PMMT.linearMaskPreview = false;
    PMMT.lowRange = 0.0000;
    PMMT.highRange = 0.0000;
    PMMT.previewMode = MultiscaleMedianTransform.prototype.Disabled;
    PMMT.previewLayer = 0;
    PMMT.toLuminance = true;
    PMMT.toChrominance = true;
    PMMT.linear = false;

    var lowerRange = dlg.lowerRangeSlider.value;
    var upperRange = dlg.upperRangeSlider.value;

    var tempLayers = [];

    for (let currentLayer = 0; currentLayer < MAX_LAYERS; ++currentLayer) {
        Console.warningln('Current layer: ' + currentLayer);

        if ((currentLayer > lowerRange) && (currentLayer < upperRange)) {
            tempLayers.push([false, true, 0.000, false, 1.0000, 1.00, 0.0000]);
        }
        else {
            tempLayers.push([true, true, 0.000, false, 1.0000, 1.00, 0.0000]);
        }
    }

    Console.warningln('tempLayers: ' + tempLayers);

    PMMT.layers = tempLayers;

    Console.warningln('PMMT.layers: ' + PMMT.layers);

    let flattenResidualWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );

    let flattenResidualView = flattenResidualWindow.mainView;
    flattenResidualView.beginProcess(UndoFlag_NoSwapFile);
    let flattenResidualImage = flattenResidualView.image;
    flattenResidualImage.apply(view.image);

    PMMT.executeOn(flattenResidualView);

    flattenResidualWindow.show();

    Console.warningln('PMMT.layers: ' + PMMT.layers);

    // return;

    var PMath = new PixelMath;
    PMath.expression = "iif(" + view.id + " == 0, $T, " + flattenResidualView.id + "*" + RSParameters.maskWindow.mainView.id + "+" + view.id + "*(1-" + RSParameters.maskWindow.mainView.id + "))";
    PMath.expression1 = "";
    PMath.expression2 = "";
    PMath.expression3 = "";
    PMath.useSingleExpression = true;
    PMath.symbols = "C,B,c";
    PMath.clearImageCacheAndExit = false;
    PMath.cacheGeneratedImages = false;
    PMath.generateOutput = true;
    PMath.singleThreaded = false;
    PMath.optimization = true;
    PMath.use64BitWorkingImage = false;
    PMath.rescale = false;
    PMath.rescaleLower = 0;
    PMath.rescaleUpper = 1;
    PMath.truncate = true;
    PMath.truncateLower = 0;
    PMath.truncateUpper = 1;
    PMath.createNewImage = false;
    PMath.showNewImage = true;
    PMath.newImageId = "";
    PMath.newImageWidth = 0;
    PMath.newImageHeight = 0;
    PMath.newImageAlpha = false;
    PMath.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    PMath.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    PMath.executeOn(flattenResidualView);

    return;
}
